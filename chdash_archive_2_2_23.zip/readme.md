# Chris Holt's All-Request Thursdays

* This implements a Python-only dashboard using dash and pandas.  
* The source is a prepared Excel document, which itself is derived from from a document curated elsewhere.

