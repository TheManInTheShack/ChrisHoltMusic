# ==============================================================================
# Dash_ART
# An implementation of a dashboard using Chris's All-Request-Thursdays data
# ==============================================================================

# ------------------------------------------------------------------------------
# Import
# ------------------------------------------------------------------------------
from datetime import datetime
import os
import sys
import argparse
import shutil
import json

import pandas as pd
import plotly.express as px
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input

sys.path.append("..\\data")
from chproc import get_marked_data

from lib import *

# ------------------------------------------------------------------------------
# Get the data
# ------------------------------------------------------------------------------
data_fname = "..\\data\\cholt_data.xlsx"
data = get_marked_data(data_fname)

# ------------------------------------------------------------------------------
# Get some universal metrics
# ------------------------------------------------------------------------------
total_shows        = len(data['Gigs'])
total_performances = len(data['Performances'])
total_songs        = len(data['Songs'])
total_albums       = len(data['Albums'])
total_artists      = len(data['Bands'])
min_year           = data['Songs']['Year'].min()
max_year           = data['Songs']['Year'].max()
year_span          = max_year - min_year + 1

# ------------------------------------------------------------------------------
# Put together the blocks of text assets
# ------------------------------------------------------------------------------
title = "Chris Holt's All Request Thursdays, Live from CH Studio in Dallas TX"

blurb_1 = "Chris Holt is an award-winning multi-instrumentalist and musical encyclopedia.  Prior to 2020, he made most of his living by playing live, mostly to local crowds in Dallas, but occasionally touring with Don Henley's band and sharing the stage with many of his musical heroes.  When the Covid-19 lockdowns changed the nature of what live performance had to be, Chris put his phone on a tripod and started streaming on Facebook once a week, working strictly on tips.  It's still going on.  Three hours a week, from 7pm to 10pm Central time on Thursdays, Chris works away at an endless list of requests from a group of his fans from all over the world.  He performs every piece himself, using his collection of instruments, by building up the layers of each song in loops, then finally performing each song in its entirety.  Each week he amazes his viewers by producing from scratch a full set of music from his vast store of knowledge, performed by a world-class musician."
blurb_2 = "So far, there have been {} shows in this series, in which Chris has done {} performances of {} songs from {} albums by {} artists, spanning {} years of music."
blurb_2 = blurb_2.format(str(total_shows), str(total_performances), str(total_songs), str(total_albums), str(total_artists), str(year_span))
blurb_3 = "All by himself, right in front of your eyes, song by song...welcome to the world of All Request Thursdays."
blurb = [html.P(blurb_1), html.P(blurb_2), html.P(blurb_3)]

footnote = ""
footnote += "Data curated by Craig Adams with Graf Weller and Chris Holt.  Dashboard implementation by Grant Dickerson. Copyright 2021."
footnote += "Rev.3"

# ------------------------------------------------------------------------------
# Put together style configuration
# ------------------------------------------------------------------------------
style_default = {}
style_default['backgroundColor']  = '#111111'
style_default['color']            = '#FFFFFF'
style_default['textAlign']        = 'center'

# ------------------------------------------------------------------------------
# Application framework
# ------------------------------------------------------------------------------
app = dash.Dash(__name__)



# ------------------------------------------------------------------------------
# Application layout
# ------------------------------------------------------------------------------
components = []
components.append(html.H1(style=style_default, children=title))
components.append(html.Div(style=style_default, children=blurb))
#components.append(html.H2(style=style_default, children="Last Set:"))
components.append(generate_table_setlist(data, style=style_default))
components.append(dcc.Graph( id='number_of_songs_by_artist', figure=get_chart(data, 'number_of_songs_by_artist', config={'min':5, 'style':style_default})))
components.append(dcc.Graph( id='number_of_songs_by_year',   figure=get_chart(data, 'number_of_songs_by_year',   config={'style':style_default})))
components.append(html.Div(style=style_default, children=footnote))

app.layout = html.Div(style=style_default, children=components)

# ------------------------------------------------------------------------------
# Application interactivity
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Run
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    print("...starting server...")
    app.run_server(debug=True)
