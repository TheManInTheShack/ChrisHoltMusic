
import pandas as pd
import plotly.express as px
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input

# ------------------------------------------------------------------------------
# Function to produce charts from the data
# ------------------------------------------------------------------------------
def get_chart(data, selection, config = {}):
    # --------------------------------------------------------------------------
    # Number of different songs played by artist (with minimum)
    # --------------------------------------------------------------------------
    if selection=="number_of_songs_by_artist":
        # ----------------------------------------------------------------------
        # Get the whole count
        # ----------------------------------------------------------------------
        count = data['Songs']['Band'].value_counts(sort=True, ascending=False)

        # ----------------------------------------------------------------------
        # Reset the minimum if requested
        # ----------------------------------------------------------------------
        if 'min' in config:
            count = count.loc[count >= config['min']]

        # ----------------------------------------------------------------------
        # Make the count into a dataframe and label the columns
        # ----------------------------------------------------------------------
        df = pd.DataFrame(list(zip(count.index.tolist(), count.tolist())), columns=["Originating Artist","Number of Songs Played"])

        # ----------------------------------------------------------------------
        # Add a column to say whether the band is one of Chris's originals
        # ----------------------------------------------------------------------
        df['CH Original'] = df['Originating Artist']
        df['CH Original'] = df['CH Original'].apply(band_is_original, args=([data['Bands']]))

        # ----------------------------------------------------------------------
        # Make it into a bar chart
        # ----------------------------------------------------------------------
        bar = px.bar(df, x='Originating Artist', y='Number of Songs Played', color='CH Original', barmode='group')

        # ----------------------------------------------------------------------
        # Update the design based on the config
        # ----------------------------------------------------------------------
        if 'style' in config: 
            if 'backgroundColor' in config['style']:
                bar.update_layout(plot_bgcolor=config['style']['backgroundColor'])
                bar.update_layout(paper_bgcolor=config['style']['backgroundColor'])
            if 'color' in config['style']:
                bar.update_layout(font_color=config['style']['color'])

        # ----------------------------------------------------------------------
        # Send back the chart
        # ----------------------------------------------------------------------
        return bar

    # --------------------------------------------------------------------------
    # Number of different songs played by year
    # --------------------------------------------------------------------------
    if selection=="number_of_songs_by_year":
        # ----------------------------------------------------------------------
        # Get the whole count
        # ----------------------------------------------------------------------
        count = data['Songs']['Year'].value_counts(sort=True, ascending=False)

        # ----------------------------------------------------------------------
        # Make the count into a dataframe and label the columns
        # ----------------------------------------------------------------------
        df = pd.DataFrame(list(zip(count.index.tolist(), count.tolist())), columns=["Year of Song's Origination","Number of Songs Played"])

        # ----------------------------------------------------------------------
        # Make it into a bar chart
        # ----------------------------------------------------------------------
        bar = px.bar(df, x="Year of Song's Origination", y="Number of Songs Played", barmode='group')

        # ----------------------------------------------------------------------
        # Update the design based on the config
        # ----------------------------------------------------------------------
        if 'style' in config: 
            if 'backgroundColor' in config['style']:
                bar.update_layout(plot_bgcolor=config['style']['backgroundColor'])
                bar.update_layout(paper_bgcolor=config['style']['backgroundColor'])
            if 'color' in config['style']:
                bar.update_layout(font_color=config['style']['color'])

        # ----------------------------------------------------------------------
        # Send back the chart
        # ----------------------------------------------------------------------
        return bar

    # --------------------------------------------------------------------------
    # Finish (no call should reach this far, but just to be complete
    # --------------------------------------------------------------------------
    return False


# ------------------------------------------------------------------------------
# Return True/False for whether the band is one of Chris's originals...takes
# in the band and the lookup table
# ------------------------------------------------------------------------------
def band_is_original(band, band_data):
    this_one = band_data['Chris Relationship'].loc[band]
    if this_one == "Original":
        return "Yes"
    else:
        return "No"

# ------------------------------------------------------------------------------
# This is the generic code to generate a table from any dataframe; it was lifted
# straight out of the Dash documentation and adapted
# ------------------------------------------------------------------------------
def generate_table(data, max_rows=50, style={}):
    head = html.Thead(html.Tr([html.Th(col) for col in data.columns]))
    body = html.Tbody([ html.Tr([html.Td(data.iloc[i][col]) for col in data.columns]) for i in range(min(len(data), max_rows)) ])
    table = html.Table([head, body])

    return table


# ------------------------------------------------------------------------------
# Compile the setlist data from multiple tables, recreating Craig's input, for
# one or more shows
# ------------------------------------------------------------------------------
def generate_table_setlist(data, filter_info={}, style={}):
    # --------------------------------------------------------------------------
    # Start with the performances
    # --------------------------------------------------------------------------
    sdata = data['Performances'][['Series Index','Set Position','Song','Artist']]

    # --------------------------------------------------------------------------
    # Filter to last show if nothing else listed
    # --------------------------------------------------------------------------
    if not filter_info:
        sdata = sdata.loc[sdata['Series Index']==max(sdata['Series Index'])]

    # --------------------------------------------------------------------------
    # Add the year and the composers from the song Table
    # --------------------------------------------------------------------------

    # --------------------------------------------------------------------------
    # Calculate the number of times played
    # --------------------------------------------------------------------------

    # --------------------------------------------------------------------------
    # Flag as CH original or not
    # --------------------------------------------------------------------------

    # --------------------------------------------------------------------------
    # 
    # --------------------------------------------------------------------------

    # --------------------------------------------------------------------------
    # Make the table for that dataframe
    # --------------------------------------------------------------------------
    table = generate_table(sdata, style=style)

    # --------------------------------------------------------------------------
    # Finish
    # --------------------------------------------------------------------------
    return table
